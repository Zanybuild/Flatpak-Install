#!/usr/bin/env bash

# Instala o Flatpak
sudo apt install flatpak

# Adiciona o repositório Flathub
flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo

# Atualiza a lista de pacotes Flatpak
flatpak update

# Instala o Flatseal, um gerenciador de permissões para Flatpaks
flatpak install flathub com.github.flatseal

# Ativa o Flatpak para todos os usuários
sudo flatpak override --user --system flatpak
